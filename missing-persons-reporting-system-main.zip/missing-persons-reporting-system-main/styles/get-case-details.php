<?php
require_once 'db_connection.php';

header('Content-Type: application/json');

try {
    $caseId = isset($_GET['id']) ? $_GET['id'] : '';
    
    if (empty($caseId)) {
        echo json_encode(['error' => 'Case ID is required']);
        exit;
    }

    $query = "SELECT * FROM approved_cases WHERE report_id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $caseId]);
    
    $case = $stmt->fetch();
    
    if (!$case) {
        echo json_encode(['error' => 'Case not found']);
        exit;
    }
    
    $response = [
        'report_id' => $case['report_id'],
        'name' => trim($case['person_first_name'] . ' ' . $case['person_last_name']),
        'age' => $case['person_age'],
        'gender' => $case['person_gender'],
        'location' => $case['location'],
        'date' => $case['event_day'],
        'description' => $case['physical_appearance'],
        'additional_description' => $case['additional_description'],
        'image' => $case['picture'] ? 'uploads/' . $case['picture'] : 'images/default-person.jpg'
    ];
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}