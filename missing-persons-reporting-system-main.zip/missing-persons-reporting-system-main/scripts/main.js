fetch("/api/get_approved_cases.php")
  .then((response) => response.json())
  .then((reports) => {
    const reportList = document.getElementById("reportList");
    reportList.innerHTML = reports
      .map(
        (report) => `
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">${report.missing_name}</h5>
            <p class="card-text">${report.last_seen_location}</p>
            <img src="${report.photo_url}" class="img-fluid" alt="Missing Person">
          </div>
        </div>
      `
      )
      .join("");
  });