// verify_report.js

document.getElementById('missingForm').addEventListener('submit', function(event) {
  event.preventDefault();

  var formData = new FormData(this);
  var formObject = {};
  formData.forEach((value, key) => {
      formObject[key] = value;
  });

  var fileInput = document.getElementById('picture');
  if (fileInput.files && fileInput.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
          formObject['photoUrl'] = e.target.result;
          displayVerificationModal(formObject);
      };
      reader.readAsDataURL(fileInput.files[0]);
  } else {
      formObject['photoUrl'] = '';
      displayVerificationModal(formObject);
  }
});

function displayVerificationModal(formObject) {
  // Reporter Details
  var reporterDetails = `
      <div class="col-md-6">
          <p><strong>First Name:</strong> ${formObject['first_name']}</p>
          <p><strong>Middle Name:</strong> ${formObject['middle_name']}</p>
          <p><strong>Last Name:</strong> ${formObject['last_name']}</p>
          <p><strong>Age:</strong> ${formObject['age']}</p>
      </div>
      <div class="col-md-6">
          <p><strong>Gender:</strong> ${formObject['gender']}</p>
          <p><strong>Permanent Residence:</strong> ${formObject['permanent_residence']}</p>
          <p><strong>Current Residence:</strong> ${formObject['current_residence']}</p>
          <p><strong>Phone Number:</strong> ${formObject['phone_number']}</p>
          <p><strong>Relationship:</strong> ${formObject['relationship']}</p>
      </div>
  `;

  // Missing Person Details
  var missingPersonDetails = `
      <div class="col-md-6">
          <p><strong>First Name:</strong> ${formObject['missing_first_name']}</p>
          <p><strong>Middle Name:</strong> ${formObject['missing_middle_name']}</p>
          <p><strong>Last Name:</strong> ${formObject['missing_last_name']}</p>
          <p><strong>Age:</strong> ${formObject['missing_age']}</p>
          <p><strong>Gender:</strong> ${formObject['missing_gender']}</p>
      </div>
      <div class="col-md-6">
          <p><strong>Last Seen Location:</strong> ${formObject['last_seen_location']}</p>
          <p><strong>Physical Appearance:</strong> ${formObject['physical_appearance']}</p>
          <p><strong>Time Last Seen:</strong> ${formObject['lost_time']}</p>
          <p><strong>Date Last Seen:</strong> ${formObject['lost_day']}</p>
          <p><strong>Additional Description:</strong> ${formObject['additional_description']}</p>
      </div>
  `;

  // Display the details in the modal
  document.getElementById('reporterDetailsDisplay').innerHTML = reporterDetails;
  document.getElementById('missingPersonDetailsDisplay').innerHTML = missingPersonDetails;

  // Handle the uploaded image
  if (formObject['photoUrl']) {
      var uploadedImagePreview = document.getElementById('uploadedImagePreview');
      uploadedImagePreview.src = formObject['photoUrl'];
      uploadedImagePreview.style.display = 'block';
  }

  // Show the verification modal
  var verificationModal = new bootstrap.Modal(document.getElementById('verificationModal'));
  verificationModal.show();

  // Handle confirmation button click
  document.getElementById('confirmSubmit').addEventListener('click', function() {
      console.log("Sending data to server:", {
          reporterName: `${formObject['first_name']} ${formObject['middle_name']} ${formObject['last_name']}`,
          reporterPhone: formObject['phone_number'],
          missingName: `${formObject['missing_first_name']} ${formObject['missing_middle_name']} ${formObject['missing_last_name']}`,
          missingAge: formObject['missing_age'],
          missingGender: formObject['missing_gender'],
          lastSeenLocation: formObject['last_seen_location'],
          physicalAppearance: formObject['physical_appearance'],
          lastSeenTime: formObject['lost_time'],
          lastSeenDate: formObject['lost_day'],
          photoUrl: formObject['photoUrl'],
          additionalDescription: formObject['additional_description'],
      });

      fetch('submit_missing_report.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({
              reporterName: `${formObject['first_name']} ${formObject['middle_name']} ${formObject['last_name']}`,
              reporterPhone: formObject['phone_number'],
              missingName: `${formObject['missing_first_name']} ${formObject['missing_middle_name']} ${formObject['missing_last_name']}`,
              missingAge: formObject['missing_age'],
              missingGender: formObject['missing_gender'],
              lastSeenLocation: formObject['last_seen_location'],
              physicalAppearance: formObject['physical_appearance'],
              lastSeenTime: formObject['lost_time'],
              lastSeenDate: formObject['lost_day'],
              photoUrl: formObject['photoUrl'],
              additionalDescription: formObject['additional_description'],
          }),
      })
      .then(response => {
          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response.json();
      })
      .then(data => {
          console.log("Server response:", data);
          if (data.message) {
              alert(data.message);
          } else if (data.error) {
              alert(data.error);
          }
      })
      .catch(error => {
          console.error('Error:', error);
          alert('Report submitted succesfully');
      });
  });
}