// Fetch and display pending reports
fetch("/api/get_pending_reports.php")
  .then((response) => response.json())
  .then((reports) => {
    const reportList = document.getElementById("reportList");
    reportList.innerHTML = reports
      .map(
        (report) => `
        <div class="card mb-3">
          <div class="card-body">
            <h5 class="card-title">${report.missing_name}</h5>
            <p class="card-text">${report.last_seen_location}</p>
            <button class="btn btn-primary" onclick="approveReport(${report.id})">Approve</button>
            <button class="btn btn-danger" onclick="rejectReport(${report.id})">Reject</button>
          </div>
        </div>
      `
      )
      .join("");
  });

// Function to approve a report
function approveReport(id) {
  updateReportStatus(id, "Approved");
}

// Function to reject a report
function rejectReport(id) {
  updateReportStatus(id, "Rejected");
}

// Function to update report status
function updateReportStatus(id, status) {
  fetch("/api/approve_report.php", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id, status }),
  })
    .then((response) => response.json())
    .then((data) => {
      alert(data.message);
      location.reload(); // Refresh the page to update the list
    })
    .catch((error) => console.error("Error:", error));
}