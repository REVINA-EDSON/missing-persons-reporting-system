
// Particle.js Background
document.addEventListener('DOMContentLoaded', () => {
  particlesJS('particles-js', {
    particles: {
      number: { value: 60, density: { enable: true, value_area: 800 } },
      color: { value: "#6C5CE7" },
      opacity: { value: 0.3, random: true },
      size: { value: 3, random: true },
      line_linked: { enable: true, distance: 150, color: "#6C5CE7", opacity: 0.2, width: 1 },
      move: { enable: true, speed: 2, direction: "none", random: true }
    },
    interactivity: { detect_on: "canvas", events: { onhover: { enable: false } } }
  });
});

// Preloader
window.addEventListener('load', () => {
  setTimeout(() => {
    document.querySelector('.page-loader').classList.add('fade-out');
  }, 500);
});

// Dark Mode Toggle
const themeToggle = document.getElementById('themeToggle');
themeToggle.addEventListener('change', () => {
  document.body.classList.toggle('dark-mode');
  localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
});

// Load Theme Preference
if (localStorage.getItem('theme') === 'dark') {
  document.body.classList.add('dark-mode');
  themeToggle.checked = true;
}

// Form Validation and Submission
const loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;

  // Bootstrap form validation
  if (!form.checkValidity()) {
    form.classList.add('was-validated');
    return;
  }

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const rememberMe = document.getElementById('rememberMe').checked;

  try {
    const response = await fetch('admin-login.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    if (data.status === 'success') {
      // Store "Remember Me" preference in localStorage (simplified)
      if (rememberMe) {
        localStorage.setItem('adminUsername', username);
      } else {
        localStorage.removeItem('adminUsername');
      }

      // Redirect to dashboard
      alert(data.message);
      window.location.href = 'admin-dashboard.html';
    } else {
      alert(data.message);
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('An error occurred during login. Please try again.');
  }
});

// Pre-fill username if "Remember Me" was previously checked
const savedUsername = localStorage.getItem('adminUsername');
if (savedUsername) {
  document.getElementById('username').value = savedUsername;
  document.getElementById('rememberMe').checked = true;
}
