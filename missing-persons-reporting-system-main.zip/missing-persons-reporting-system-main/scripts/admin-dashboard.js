

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(el => new bootstrap.Tooltip(el));

    // Live DateTime
    function updateDateTime() {
      const now = new Date();
      document.getElementById('liveDateTime').textContent = 
        now.toLocaleString('en-US', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric', 
          hour: '2-digit', 
          minute: '2-digit' 
        });
    }
    setInterval(updateDateTime, 60000);
    updateDateTime();

    // Back to Top Button
    window.addEventListener('scroll', () => {
      const btn = document.getElementById('backToTop');
      btn.style.display = window.scrollY > 300 ? 'block' : 'none';
    });
    document.getElementById('backToTop').addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Preloader
    window.addEventListener('load', () => {
      setTimeout(() => {
        document.querySelector('.page-loader').classList.add('fade-out');
      }, 500);
    });

    // Particle.js Background
    document.addEventListener('DOMContentLoaded', () => {
      particlesJS('particles-js', {
        particles: {
          number: { value: 60, density: { enable: true, value_area: 800 } },
          color: { value: "#6C5CE7" },
          opacity: { value: 0.3, random: true },
          size: { value: 3, random: true },
          line_linked: { enable: true, distance: 150, color: "#6C5CE7", opacity: 0.2, width: 1 },
          move: { enable: true, speed: 2, direction: "none", random: true }
        },
        interactivity: { detect_on: "canvas", events: { onhover: { enable: false } } }
      });
    });

    // Sidebar Toggle Functionality
    document.getElementById('sidebarToggle').addEventListener('click', function() {
      const sidebar = document.getElementById('sidebar');
      const mainContent = document.getElementById('mainContent');
      const topNav = document.getElementById('topNav');
      const toggleBtn = document.getElementById('sidebarToggle');
      
      sidebar.classList.toggle('show');
      mainContent.classList.toggle('shifted');
      topNav.classList.toggle('shifted');
      toggleBtn.classList.toggle('show');
      
      // Adjust content width when sidebar is open
      if (sidebar.classList.contains('show')) {
        document.body.style.overflowX = 'hidden';
      } else {
        document.body.style.overflowX = 'auto';
      }
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      const sidebar = document.getElementById('sidebar');
      const toggleBtn = document.getElementById('sidebarToggle');
      const mainContent = document.getElementById('mainContent');
      const topNav = document.getElementById('topNav');
      
      if (window.innerWidth <= 768 && 
          !e.target.closest('#sidebar') && 
          !e.target.closest('#sidebarToggle') && 
          sidebar.classList.contains('show')) {
        sidebar.classList.remove('show');
        mainContent.classList.remove('shifted');
        topNav.classList.remove('shifted');
        toggleBtn.classList.remove('show');
      }
    });

    // Dropdown Menu Functionality
    document.getElementById('reportsDropdown').addEventListener('click', function(e) {
      e.preventDefault();
      const menu = document.getElementById('reportsMenu');
      menu.classList.toggle('show');
      this.querySelector('.dropdown-icon').classList.toggle('fa-chevron-down');
      this.querySelector('.dropdown-icon').classList.toggle('fa-chevron-up');
    });

    // Dark mode toggle
    document.getElementById('themeToggle').addEventListener('click', function() {
      document.body.classList.toggle('dark-mode');
      if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark');
        this.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
      } else {
        localStorage.setItem('theme', 'light');
        this.innerHTML = '<i class="fas fa-moon"></i> Dark Mode';
      }
    });

    // Check for saved theme preference
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark-mode');
      document.getElementById('themeToggle').innerHTML = '<i class="fas fa-sun"></i> Light Mode';
    }

    // Original Dashboard Functionality (unchanged)
    const missingTable = document.getElementById("missingTable").querySelector("tbody");
    const foundTable = document.getElementById("foundTable").querySelector("tbody");
    const totalMissingElement = document.getElementById("totalMissing");
    const totalFoundElement = document.getElementById("totalFound");
    const pendingReportsElement = document.getElementById("pendingReports");
    let totalMissing = 0;
    let totalFound = 0;
    let pendingReports = 0;
    const missingAgeData = {};
    const foundGenderData = { Male: 0, Female: 0, Other: 0 };

    const missingAgeChartCtx = document.getElementById("missingAgeChart").getContext("2d");
    const foundGenderChartCtx = document.getElementById("foundGenderChart").getContext("2d");

    const missingAgeChart = new Chart(missingAgeChartCtx, {
      type: "bar",
      data: {
        labels: [],
        datasets: [{
          label: "Number of People",
          data: [],
          backgroundColor: ["rgba(108, 92, 231, 0.6)", "rgba(0, 206, 201, 0.6)", "rgba(253, 203, 110, 0.6)", "rgba(255, 118, 117, 0.6)", "rgba(0, 184, 148, 0.6)"],
          borderColor: ["rgba(108, 92, 231, 1)", "rgba(0, 206, 201, 1)", "rgba(253, 203, 110, 1)", "rgba(255, 118, 117, 1)", "rgba(0, 184, 148, 1)"],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
          title: { display: false }, 
          legend: { display: false } 
        },
        scales: { 
          y: { beginAtZero: true, grid: { color: "rgba(0,0,0,0.05)" } },
          x: { grid: { display: false } }
        }
      }
    });

    const foundGenderChart = new Chart(foundGenderChartCtx, {
      type: "pie",
      data: {
        labels: ["Male", "Female", "Other"],
        datasets: [{
          label: "Number of People",
          data: [0, 0, 0],
          backgroundColor: ["rgba(108, 92, 231, 0.8)", "rgba(255, 118, 117, 0.8)", "rgba(253, 203, 110, 0.8)"],
          borderColor: ["rgba(108, 92, 231, 1)", "rgba(255, 118, 117, 1)", "rgba(253, 203, 110, 1)"],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
          title: { display: false },
          legend: { position: "bottom" } 
        }
      }
    });

    function fetchData() {
      fetch('admin-dashboard-data.php')
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            console.error("Error fetching data:", data.error);
            return;
          }
          totalMissing = data.totalMissing;
          totalFound = data.totalFound;
          pendingReports = data.pendingReports;
          totalMissingElement.textContent = totalMissing;
          totalFoundElement.textContent = totalFound;
          pendingReportsElement.textContent = pendingReports;

          // Populate missing table
          missingTable.innerHTML = '';
          data.missing.forEach(item => {
            const row = missingTable.insertRow();
            row.innerHTML = `
              <td>${item.report_id}</td>
              <td>${item.missing_first_name} ${item.missing_middle_name || ''} ${item.missing_last_name}</td>
              <td>${item.missing_age}</td>
              <td>${item.missing_gender || 'Unknown'}</td>
              <td>${item.last_seen_location}</td>
              <td>${item.report_date}</td>
              <td class="text-end">
                <button class="btn btn-success btn-sm approve-btn me-1" data-id="${item.report_id}" data-type="missing">Approve</button>
                <button class="btn btn-danger btn-sm reject-btn" data-id="${item.report_id}" data-type="missing">Reject</button>
              </td>
            `;
            // Update chart data
            missingAgeData[item.missing_age] = (missingAgeData[item.missing_age] || 0) + 1;
          });
          missingAgeChart.data.labels = Object.keys(missingAgeData);
          missingAgeChart.data.datasets[0].data = Object.values(missingAgeData);
          missingAgeChart.update();

          // Populate found table
          foundTable.innerHTML = '';
          data.found.forEach(item => {
            const row = foundTable.insertRow();
            row.innerHTML = `
              <td>${item.report_id}</td>
              <td>${item.found_first_name || 'Unknown'} ${item.found_middle_name || ''} ${item.found_last_name || ''}</td>
              <td>${item.found_age}</td>
              <td>${item.found_gender}</td>
              <td>${item.found_location}</td>
              <td>${item.report_date}</td>
              <td class="text-end">
                <button class="btn btn-success btn-sm approve-btn me-1" data-id="${item.report_id}" data-type="found">Approve</button>
                <button class="btn btn-danger btn-sm reject-btn" data-id="${item.report_id}" data-type="found">Reject</button>
              </td>
            `;
            // Update chart data
            foundGenderData[item.found_gender] = (foundGenderData[item.found_gender] || 0) + 1;
          });
          foundGenderChart.data.datasets[0].data = Object.values(foundGenderData);
          foundGenderChart.update();

          // Add event listeners for approve/reject buttons
          document.querySelectorAll('.approve-btn').forEach(btn => {
            btn.addEventListener('click', () => handleAction(btn.dataset.id, btn.dataset.type, 'approve'));
          });
          document.querySelectorAll('.reject-btn').forEach(btn => {
            btn.addEventListener('click', () => handleAction(btn.dataset.id, btn.dataset.type, 'reject'));
          });
        })
        .catch(error => console.error("Error:", error));
    }

    function handleAction(reportId, type, action) {
      fetch('approve_report.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ report_id: reportId, type: type, action: action })
      })
      .then(response => response.json())
      .then(data => {
        if (data.status === 'success') {
          alert(`${action.charAt(0).toUpperCase() + action.slice(1)}d successfully`);
          fetchData(); // Refresh dashboard
        } else {
          alert(`Error: ${data.message}`);
        }
      })
      .catch(error => console.error("Error:", error));
    }

    function setupRealTimeUpdates() {
      const socket = new WebSocket("ws://your-server-address:8080"); // Replace with your server address
      socket.onopen = () => console.log("Connected to WebSocket server");
      socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        fetchData(); // Refresh on new data
      };
      socket.onclose = () => console.log("Disconnected from WebSocket server");
      socket.onerror = (error) => console.error("WebSocket error:", error);
    }

    window.onload = () => {
      fetchData();
      setupRealTimeUpdates();
    };
