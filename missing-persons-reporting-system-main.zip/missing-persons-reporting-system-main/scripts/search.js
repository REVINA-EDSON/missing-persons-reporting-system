document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    const resultsList = document.getElementById('resultsList');
    
    // Handle form submission
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        performSearch();
    });
    
    // Handle input changes with debounce
    let searchTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        if (searchInput.value.trim().length > 2) {
            searchTimeout = setTimeout(performSearch, 300);
        } else {
            searchResults.style.display = 'none';
        }
    });
    
    // Click outside to close results
    document.addEventListener('click', function(e) {
        if (!searchResults.contains(e.target) && e.target !== searchInput) {
            searchResults.style.display = 'none';
        }
    });
    
    function performSearch() {
        const query = searchInput.value.trim();
        if (query.length < 3) {
            searchResults.style.display = 'none';
            return;
        }
        
        fetch(`search.php?q=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error(data.error);
                    return;
                }
                
                resultsList.innerHTML = '';
                
                if (data.length === 0) {
                    const li = document.createElement('li');
                    li.className = 'list-group-item text-center py-3';
                    li.textContent = 'No results found';
                    resultsList.appendChild(li);
                } else {
                    data.forEach(result => {
                        const li = document.createElement('li');
                        li.className = 'list-group-item';
                        li.innerHTML = `
                            <a href="case-details.html?id=${result.id}" class="text-decoration-none text-dark">
                                <div class="d-flex align-items-center">
                                    <img src="${result.image}" alt="${result.name}" 
                                         class="rounded-circle me-3" width="50" height="50">
                                    <div>
                                        <h6 class="mb-0">${result.name}</h6>
                                        <small class="text-muted">
                                            ${result.age} years, ${result.gender} - Last seen in ${result.location}
                                        </small>
                                    </div>
                                </div>
                            </a>
                        `;
                        resultsList.appendChild(li);
                    });
                }
                
                // Position and show the results dropdown
                const inputRect = searchInput.getBoundingClientRect();
                searchResults.style.width = inputRect.width + 'px';
                searchResults.style.left = inputRect.left + 'px';
                searchResults.style.top = (inputRect.bottom + window.scrollY) + 'px';
                searchResults.style.display = 'block';
            })
            .catch(error => {
                console.error('Search error:', error);
            });
    }
});
