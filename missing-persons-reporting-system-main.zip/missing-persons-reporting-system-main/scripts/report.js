document.getElementById("missingForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const formData = {
      reporterName: document.getElementById("first-name").value,
      reporterPhone: document.getElementById("phone-number").value,
      missingName: document.getElementById("missing-first-name").value,
      missingAge: document.getElementById("missing-age").value,
      missingGender: document.getElementById("missing-gender").value,
      lastSeenLocation: document.getElementById("last-seen-location").value,
      physicalAppearance: document.getElementById("physical-appearance").value,
      lastSeenTime: document.getElementById("lost-time").value,
      lastSeenDate: document.getElementById("lost-day").value,
      photoUrl: document.getElementById("picture").files[0]?.name || "placeholder.jpg",
      additionalDescription: document.getElementById("additional-description").value,
    };
  
    fetch("D:\FYP\missing-persons-tracker\api\submit_report.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        alert(data.message);
        document.getElementById("missingForm").reset();
      })
      .catch((error) => console.error("Error:", error));
  });