document.addEventListener('DOMContentLoaded', function() {
    const postsContainer = document.querySelector('.public-posts .row');
    const paginationContainer = document.createElement('div');
    paginationContainer.className = 'pagination-container mt-4 d-flex justify-content-center';
    postsContainer.parentNode.appendChild(paginationContainer);

    // Initialize modal instance
    const detailsModal = new bootstrap.Modal(document.getElementById('viewDetailsModal'));
    let currentPage = 1;
    let isLoading = false;

    async function loadReports(page) {
        if (isLoading) return;
        isLoading = true;
        showSkeletonLoading();
        try {
            const response = await fetch(`fetch_reports.php?page=${page}`);
            const data = await response.json();
            if (!data.success) throw new Error(data.message || 'Failed to load reports');
            postsContainer.innerHTML = '';
            if (data.data.reports.length === 0) {
                showNoResults();
                return;
            }
            createReportCards(data.data.reports);
            updatePaginationControls(data.data.pagination.total_pages, page);
        } catch (error) {
            console.error('Error:', error);
            showErrorState(error);
        } finally {
            isLoading = false;
        }
    }

    function showSkeletonLoading() {
        postsContainer.innerHTML = '';
        for (let i = 0; i < 4; i++) {
            postsContainer.innerHTML += `
                <div class="report-wrapper mx-auto mb-4">
                    <div class="card h-100">
                        <div class="card-img-container">
                            <div class="card-img-top loading" style="height: 320px;"></div>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title placeholder-glow">
                                <span class="placeholder col-6"></span>
                            </h5>
                            <p class="card-text placeholder-glow">
                                <span class="placeholder col-7"></span>
                                <span class="placeholder col-4"></span>
                                <span class="placeholder col-4"></span>
                                <span class="placeholder col-6"></span>
                            </p>
                            <a class="btn btn-primary disabled placeholder col-6"></a>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    function createReportCards(reports) {
        reports.forEach(report => {
            const badgeColor = report.type === 'missing' ? 'bg-danger' : 'bg-success';
            const reportCard = document.createElement('div');
            reportCard.className = 'report-wrapper mx-auto mb-4';
            reportCard.innerHTML = `
                <div class="card h-100">
                    <div class="card-img-container position-relative text-center bg-light p-2">
                        <img src="${report.picture_path}" 
                             class="card-img-top img-fluid rounded-top"
                             alt="${report.person_first_name || 'Person'}"
                             onerror="this.onerror=null;this.src='/missing-persons-reporting-system/assets/default-profile.jpg'"
                             loading="lazy"
                             style="object-fit: contain; height: auto; max-height: 320px; width: 100%; background-color: #f8f9fa;">
                        <span class="position-absolute top-0 start-0 m-2 badge ${badgeColor}" style="font-size: 0.85rem;">
                            ${report.status_text}
                        </span>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title mb-3 text-primary">
                            <i class="fas fa-user me-2"></i>
                            ${report.person_first_name || 'Unknown'} 
                            ${report.person_middle_name || ''} 
                            ${report.person_last_name || ''}
                        </h5>
                        
                        <div class="details-grid mb-3">
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <div class="detail-content">
                                    <div class="detail-label">Age</div>
                                    <div class="detail-value">${report.person_age}</div>
                                </div>
                            </div>
                            
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-venus-mars"></i>
                                </div>
                                <div class="detail-content">
                                    <div class="detail-label">Gender</div>
                                    <div class="detail-value">${report.person_gender}</div>
                                </div>
                            </div>
                            
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="detail-content">
                                    <div class="detail-label">Last Seen</div>
                                    <div class="detail-value text-truncate" title="${report.location}">
                                        ${report.location}
                                    </div>
                                </div>
                            </div>
                            
                            <div class="detail-item">
                                <div class="detail-icon">
                                    <i class="far fa-calendar-alt"></i>
                                </div>
                                <div class="detail-content">
                                    <div class="detail-label">Reported</div>
                                    <div class="detail-value">${report.formatted_date}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="description-section mb-3">
                            <div class="description-header d-flex align-items-center mb-2">
                                <i class="fas fa-info-circle me-2 text-muted"></i>
                                <h6 class="mb-0 text-muted">Description</h6>
                            </div>
                            <div class="description-text p-2 bg-light rounded">
                                <p class="mb-0">
                                    ${report.physical_appearance.substring(0, 120)}${report.physical_appearance.length > 120 ? '...' : ''}
                                </p>
                            </div>
                        </div>
                        
                        <div class="card-actions mt-auto pt-2 border-top">
                            <button class="btn btn-primary btn-sm view-details-btn" data-id="${report.report_id}">
                                <i class="fas fa-search me-1"></i> View Details
                            </button>
                            <button class="btn btn-outline-primary btn-sm share-btn" data-id="${report.report_id}">
                                <i class="fas fa-share-alt me-1"></i> Share
                            </button>
                        </div>
                    </div>
                </div>
            `;
            postsContainer.appendChild(reportCard);
        });

        // Initialize view details buttons
        document.querySelectorAll('.view-details-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const reportId = this.getAttribute('data-id');
                showReportDetailsModal(reportId);
            });
        });

        // Initialize share buttons
        initShareButtons();

        // Card hover effects
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                const img = card.querySelector('.card-img-top');
                if (img) img.style.transform = 'scale(1.02)';
            });
            card.addEventListener('mouseleave', () => {
                const img = card.querySelector('.card-img-top');
                if (img) img.style.transform = 'scale(1)';
            });
        });
    }

    async function showReportDetailsModal(reportId) {
        const modalBody = document.getElementById('modalBodyContent');
        const modalTitle = document.getElementById('detailsModalTitle');
        
        // Show loading state
        modalBody.innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading details...</p>
            </div>
        `;
        
        // Set temporary title
        modalTitle.textContent = 'Loading Details...';
        
        // Show modal
        detailsModal.show();

        try {
            // Fetch report details
            const response = await fetch(`view-case-details.php?id=${reportId}`);
            const data = await response.json();
            
            if (!data.success) throw new Error(data.message || 'Failed to load details');
            
            const report = data.report;
            const badgeClass = report.type === 'missing' ? 'bg-danger' : 'bg-success';
            
            // Update modal title
            modalTitle.textContent = `${report.person_first_name || 'Unknown'} ${report.person_last_name || ''}`;
            
            // Populate modal content
            modalBody.innerHTML = `
                <div class="row">
                    <div class="col-md-5 mb-4 mb-md-0">
                        <img src="${report.picture_path}" 
                             class="img-fluid rounded shadow-sm"
                             alt="${report.person_first_name || 'Person'}"
                             onerror="this.onerror=null;this.src='/missing-persons-reporting-system/assets/default-profile.jpg'"
                             style="max-height: 400px; width: 100%; object-fit: contain;">
                    </div>
                    <div class="col-md-7">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h4 class="mb-0">
                                ${report.person_first_name || 'Unknown'} 
                                ${report.person_middle_name || ''} 
                                ${report.person_last_name || ''}
                            </h4>
                            <span class="badge ${badgeClass} ms-2" style="font-size: 0.85rem;">
                                ${report.status_text}
                            </span>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-sm-6 mb-2">
                                <p class="mb-1"><strong><i class="fas fa-user-circle me-2 text-muted"></i>Age</strong></p>
                                <p>${report.person_age || 'Unknown'}</p>
                            </div>
                            <div class="col-sm-6 mb-2">
                                <p class="mb-1"><strong><i class="fas fa-venus-mars me-2 text-muted"></i>Gender</strong></p>
                                <p>${report.person_gender || 'Unknown'}</p>
                            </div>
                            <div class="col-sm-6 mb-2">
                                <p class="mb-1"><strong><i class="fas fa-map-marker-alt me-2 text-muted"></i>Last Seen Location</strong></p>
                                <p>${report.location || 'Unknown'}</p>
                            </div>
                            <div class="col-sm-6 mb-2">
                                <p class="mb-1"><strong><i class="far fa-calendar-alt me-2 text-muted"></i>Date Reported</strong></p>
                                <p>${report.formatted_date || 'Unknown'}</p>
                            </div>
                            ${report.event_day ? `
                            <div class="col-sm-6 mb-2">
                                <p class="mb-1"><strong><i class="far fa-calendar me-2 text-muted"></i>Date Occurred</strong></p>
                                <p>${report.event_day}</p>
                            </div>
                            ` : ''}
                        </div>
                        
                        <div class="mb-4">
                            <h5 class="d-flex align-items-center mb-3">
                                <i class="fas fa-info-circle me-2 text-muted"></i>
                                <span>Physical Description</span>
                            </h5>
                            <div class="bg-light p-3 rounded">
                                <p class="mb-0">${report.physical_appearance || 'No description available'}</p>
                            </div>
                        </div>
                        
                        ${report.additional_notes ? `
                        <div class="mb-4">
                            <h5 class="d-flex align-items-center mb-3">
                                <i class="fas fa-sticky-note me-2 text-muted"></i>
                                <span>Additional Notes</span>
                            </h5>
                            <div class="bg-light p-3 rounded">
                                <p class="mb-0">${report.additional_notes}</p>
                            </div>
                        </div>
                        ` : ''}
                        
                        ${report.contact_information ? `
                        <div class="mb-3">
                            <h5 class="d-flex align-items-center mb-3">
                                <i class="fas fa-phone-alt me-2 text-muted"></i>
                                <span>Contact Information</span>
                            </h5>
                            <div class="bg-light p-3 rounded">
                                <p class="mb-0">${report.contact_information}</p>
                            </div>
                        </div>
                        ` : ''}
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading details:', error);
            modalBody.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Error loading details</strong>
                    <p class="mt-2 mb-0">${error.message || 'Please try again later'}</p>
                </div>
                <div class="text-center mt-3">
                    <button class="btn btn-primary" onclick="location.reload()">
                        <i class="fas fa-sync-alt me-1"></i> Reload Page
                    </button>
                </div>
            `;
        }
    }

    function initShareButtons() {
        document.querySelectorAll('.share-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const reportId = this.getAttribute('data-id');
                alert('Share functionality would open for report: ' + reportId);
                // Implement actual sharing functionality here
            });
        });
    }

    function updatePaginationControls(totalPages, currentPage) {
        paginationContainer.innerHTML = '';
        if (totalPages <= 1) return;

        const prevButton = document.createElement('button');
        prevButton.className = 'btn btn-outline-primary mx-1 pagination-btn';
        prevButton.innerHTML = '<i class="fas fa-chevron-left me-1"></i> Previous';
        prevButton.disabled = currentPage === 1;
        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                window.scrollTo({ top: postsContainer.offsetTop - 100, behavior: 'smooth' });
                loadReports(currentPage - 1);
            }
        });

        const nextButton = document.createElement('button');
        nextButton.className = 'btn btn-outline-primary mx-1 pagination-btn';
        nextButton.innerHTML = 'Next <i class="fas fa-chevron-right ms-1"></i>';
        nextButton.disabled = currentPage === totalPages;
        nextButton.addEventListener('click', () => {
            if (currentPage < totalPages) {
                window.scrollTo({ top: postsContainer.offsetTop - 100, behavior: 'smooth' });
                loadReports(currentPage + 1);
            }
        });

        const pageInfo = document.createElement('span');
        pageInfo.className = 'mx-3 align-self-center text-muted';
        pageInfo.innerHTML = `Page <strong>${currentPage}</strong> of <strong>${totalPages}</strong>`;

        paginationContainer.append(prevButton, pageInfo, nextButton);
    }

    function showNoResults() {
        postsContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="empty-state">
                    <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                    <h4 class="mb-2">No reports found</h4>
                    <p class="text-muted">There are currently no missing or found person reports</p>
                    <div class="mt-4">
                        <a href="report-missing.html" class="btn btn-primary me-2">
                            <i class="fas fa-user-times me-1"></i> Report Missing
                        </a>
                        <a href="report-found.html" class="btn btn-success">
                            <i class="fas fa-user-check me-1"></i> Report Found
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    function showErrorState(error) {
        postsContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="error-state">
                    <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                    <h4 class="mb-2">Error loading reports</h4>
                    <p class="text-muted">${error.message || 'Please try again later'}</p>
                    <button class="btn btn-outline-primary mt-3" onclick="location.reload()">
                        <i class="fas fa-sync-alt me-1"></i> Reload Page
                    </button>
                </div>
            </div>
        `;
    }

    // Initial load
    loadReports(currentPage);

    // Add styles
    const style = document.createElement('style');
    style.textContent = `
        .text-truncate-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .pagination-btn {
            min-width: 100px;
        }
        .public-posts .row {
            flex-direction: column !important;
        }
        .report-wrapper {
            width: 100%;
            max-width: 720px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.75rem;
        }
        .detail-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .detail-icon {
            color: #6c757d;
            font-size: 0.9rem;
            width: 1.5rem;
            text-align: center;
        }
        .detail-content {
            flex: 1;
        }
        .detail-label {
            font-size: 0.75rem;
            color: #6c757d;
            line-height: 1;
        }
        .detail-value {
            font-size: 0.9rem;
            font-weight: 500;
            line-height: 1.2;
        }
        .description-section {
            font-size: 0.9rem;
        }
        .description-text {
            font-size: 0.85rem;
            line-height: 1.5;
        }
        .card-actions {
            display: flex;
            justify-content: space-between;
            gap: 0.5rem;
        }
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
        }
        .loading {
            background-color: #e9ecef;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        #viewDetailsModal .modal-body {
            max-height: 70vh;
            overflow-y: auto;
        }
        @media (max-width: 768px) {
            #viewDetailsModal .modal-body {
                max-height: 60vh;
            }
        }
    `;
    document.head.appendChild(style);
});