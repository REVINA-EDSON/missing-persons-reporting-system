document.addEventListener('DOMContentLoaded', function() {
    // Form validation before submission
    const form = document.getElementById('missingForm');
    const requiredFields = [
        'first_name', 'last_name', 'age', 'gender',
        'permanent_residence', 'current_residence', 'phone_number', 'relationship',
        'missing_first_name', 'missing_last_name', 'missing_age', 'missing_gender',
        'last_seen_location', 'physical_appearance', 'lost_time', 'lost_day'
    ];

    // Add real-time validation
    requiredFields.forEach(field => {
        const input = form.querySelector(`[name="${field}"]`);
        if (input) {
            input.addEventListener('blur', validateField);
        }
    });

    // Field validation function
    function validateField(e) {
        const field = e.target;
        const value = field.value.trim();
        const fieldName = field.getAttribute('name');
        
        // Special validation for specific fields
        if (fieldName === 'phone_number') {
            if (!/^[0-9]{10,15}$/.test(value.replace(/\D/g, ''))) {
                showError(field, 'Please enter a valid phone number (10-15 digits)');
                return false;
            }
        } else if (fieldName === 'age' || fieldName === 'missing_age') {
            if (isNaN(value) || value < 1 || value > 120) {
                showError(field, 'Please enter a valid age (1-120)');
                return false;
            }
        } else if (value === '') {
            showError(field, 'This field is required');
            return false;
        }
        
        clearError(field);
        return true;
    }

    // Error display helpers
    function showError(field, message) {
        clearError(field);
        field.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.textContent = message;
        field.parentNode.appendChild(errorDiv);
    }

    function clearError(field) {
        field.classList.remove('is-invalid');
        const errorDiv = field.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    // Form submission handler
    form.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        // Validate all fields
        let isValid = true;
        requiredFields.forEach(fieldName => {
            const field = form.querySelector(`[name="${fieldName}"]`);
            if (!validateField({ target: field })) {
                isValid = false;
            }
        });

        // Validate file upload
        const fileInput = document.getElementById('picture');
        if (fileInput.files.length === 0) {
            showError(fileInput, 'Please upload a photo');
            isValid = false;
        } else {
            const file = fileInput.files[0];
            const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!validTypes.includes(file.type)) {
                showError(fileInput, 'Only JPG, PNG or GIF images are allowed');
                isValid = false;
            }
            if (file.size > 5 * 1024 * 1024) { // 5MB
                showError(fileInput, 'Image must be smaller than 5MB');
                isValid = false;
            }
        }

        if (!isValid) {
            // Scroll to first error
            const firstError = form.querySelector('.is-invalid');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            return;
        }

        // Prepare form data for verification modal
        prepareVerificationModal();

        // Show verification modal
        const verificationModal = new bootstrap.Modal(document.getElementById('verificationModal'));
        verificationModal.show();
    });

    // Prepare verification modal content
    function prepareVerificationModal() {
        const formData = new FormData(document.getElementById('missingForm'));
        
        // Reporter Details
        document.getElementById('reporterDetailsDisplay').innerHTML = `
            <div class="col-md-4"><strong>First Name:</strong> ${formData.get('first_name')}</div>
            <div class="col-md-4"><strong>Middle Name:</strong> ${formData.get('middle_name') || 'N/A'}</div>
            <div class="col-md-4"><strong>Last Name:</strong> ${formData.get('last_name')}</div>
            <div class="col-md-4"><strong>Age:</strong> ${formData.get('age')}</div>
            <div class="col-md-4"><strong>Gender:</strong> ${formData.get('gender')}</div>
            <div class="col-md-4"><strong>Permanent Residence:</strong> ${formData.get('permanent_residence')}</div>
            <div class="col-md-4"><strong>Current Residence:</strong> ${formData.get('current_residence')}</div>
            <div class="col-md-4"><strong>Phone Number:</strong> ${formData.get('phone_number')}</div>
            <div class="col-md-4"><strong>Relationship:</strong> ${formData.get('relationship')}</div>
        `;

        // Missing Person Details
        document.getElementById('missingPersonDetailsDisplay').innerHTML = `
            <div class="col-md-4"><strong>First Name:</strong> ${formData.get('missing_first_name')}</div>
            <div class="col-md-4"><strong>Middle Name:</strong> ${formData.get('missing_middle_name') || 'N/A'}</div>
            <div class="col-md-4"><strong>Last Name:</strong> ${formData.get('missing_last_name')}</div>
            <div class="col-md-4"><strong>Age:</strong> ${formData.get('missing_age')}</div>
            <div class="col-md-4"><strong>Gender:</strong> ${formData.get('missing_gender')}</div>
            <div class="col-md-4"><strong>Last Seen Location:</strong> ${formData.get('last_seen_location')}</div>
            <div class="col-md-12"><strong>Physical Appearance:</strong> ${formData.get('physical_appearance')}</div>
            <div class="col-md-4"><strong>Time Last Seen:</strong> ${formData.get('lost_time')}</div>
            <div class="col-md-4"><strong>Date Last Seen:</strong> ${formData.get('lost_day')}</div>
        `;

        // Image Preview
        const fileInput = document.getElementById('picture');
        if (fileInput.files && fileInput.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const imgPreview = document.getElementById('uploadedImagePreview');
                imgPreview.src = e.target.result;
                imgPreview.style.display = 'block';
            };
            reader.readAsDataURL(fileInput.files[0]);
        }
    }

    // Confirm submission handler
    document.getElementById('confirmSubmit').addEventListener('click', async function() {
        const form = document.getElementById('missingForm');
        const formData = new FormData(form);
        const submitBtn = this;
        
        // Disable button during submission
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';

        try {
            const response = await fetch('submit_missing_report.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Submission failed');
            }

            if (result.status === 'success') {
                // Show success message
                const modal = bootstrap.Modal.getInstance(document.getElementById('verificationModal'));
                modal.hide();
                
                // Show success alert
                const alertHTML = `
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> ${result.message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;
                
                document.body.insertAdjacentHTML('afterbegin', alertHTML);
                
                // Redirect after 3 seconds
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 3000);
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            console.error('Submission error:', error);
            
            // Show error alert
            const alertHTML = `
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error!</strong> ${error.message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            `;
            
            document.body.insertAdjacentHTML('afterbegin', alertHTML);
            
            // Re-enable button
            submitBtn.disabled = false;
            submitBtn.textContent = 'Confirm';
        }
    });
});