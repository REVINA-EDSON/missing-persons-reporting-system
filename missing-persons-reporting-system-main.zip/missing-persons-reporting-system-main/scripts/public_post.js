
$(document).ready(function() {
    // Load cases when page loads
    loadCases('missing');
    loadCases('found');
    
    // Load cases when tab is changed
    $('#casesTab button').on('shown.bs.tab', function (e) {
        const target = $(e.target).data('bs-target');
        if (target === '#missing-tab-pane') {
            if ($('#missingPersonsContainer').children('.post-card').length === 0) {
                loadCases('missing');
            }
        } else if (target === '#found-tab-pane') {
            if ($('#foundPersonsContainer').children('.post-card').length === 0) {
                loadCases('found');
            }
        }
    });
});

function loadCases(type) {
    const containerId = type + 'PersonsContainer';
    const $container = $('#' + containerId);
    
    // Show loading state
    $container.html(`
        <div class="loading-container">
            <div class="spinner-border loading-spinner" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `);
    
    $.ajax({
        url: `get_public_${type}_cases.php`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success && response.cases.length > 0) {
                renderCases(response.cases, containerId, type);
            } else {
                showNoCasesMessage(containerId, type);
            }
        },
        error: function(xhr, status, error) {
            showError(containerId, type, error);
        }
    });
}

function renderCases(cases, containerId, type) {
    const $container = $('#' + containerId);
    $container.empty();
    
    if (cases.length === 0) {
        showNoCasesMessage(containerId, type);
        return;
    }
    
    cases.forEach(caseData => {
        const fullName = `${caseData.person_first_name || 'Unknown'} ${caseData.person_last_name || ''}`.trim();
        const imagePath = caseData.picture ? `uploads/${caseData.picture}` : 'uploads/default-profile.jpg';
        
        const postHtml = `
            <div class="post-card" data-case-id="${caseData.report_id}">
                <div class="position-relative">
                    <img src="${imagePath}" 
                         class="post-image" 
                         alt="${fullName}"
                         onerror="this.src='uploads/default-profile.jpg'">
                    <span class="post-type-badge ${type === 'missing' ? 'missing-badge' : 'found-badge'}">
                        ${type === 'missing' ? 'Missing' : 'Found'}
                    </span>
                </div>
                <div class="post-body">
                    <h3 class="post-title">${fullName}</h3>
                    <div class="post-meta">
                        <div class="post-meta-item">
                            <i class="fas fa-user"></i>
                            <span>${caseData.person_age || 'Unknown'} years</span>
                        </div>
                        <div class="post-meta-item">
                            <i class="fas fa-${caseData.person_gender === 'Male' ? 'mars' : 'venus'}"></i>
                            <span>${caseData.person_gender || 'Unknown'}</span>
                        </div>
                        <div class="post-meta-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${caseData.location || 'Unknown location'}</span>
                        </div>
                    </div>
                    <p class="post-description">
                        <strong>${type === 'missing' ? 'Last seen' : 'Found'} on:</strong> 
                        ${formatDate(caseData.event_day)} at ${formatTime(caseData.event_time)}
                    </p>
                    <p class="post-description">
                        <strong>Description:</strong> 
                        ${caseData.physical_appearance || 'No description available'}
                    </p>
                    <button class="btn btn-primary view-details-btn" 
                            data-case-id="${caseData.report_id}"
                            data-case-type="${type}">
                        <i class="fas fa-info-circle me-2"></i>View Full Details
                    </button>
                </div>
            </div>
        `;
        
        $container.append(postHtml);
    });
    
    // Add click handlers for view details buttons
    $('.view-details-btn').click(function() {
        const caseId = $(this).data('case-id');
        const caseType = $(this).data('case-type');
        viewCaseDetails(caseId, caseType);
    });
}

function showNoCasesMessage(containerId, type) {
    const $container = $('#' + containerId);
    $container.html(`
        <div class="no-posts-message">
            <div class="no-posts-icon">
                <i class="fas fa-${type === 'missing' ? 'search' : 'check-circle'}"></i>
            </div>
            <h4>No ${type} persons found</h4>
            <p class="text-muted">There are currently no ${type} person reports. Check back later or report a ${type} person.</p>
            <a href="report-${type}.html" class="btn btn-primary mt-2">
                <i class="fas fa-${type === 'missing' ? 'user-slash' : 'user-check'} me-2"></i>
                Report ${type === 'missing' ? 'Missing' : 'Found'} Person
            </a>
        </div>
    `);
}

function showError(containerId, type, error) {
    const $container = $('#' + containerId);
    $container.html(`
        <div class="no-posts-message">
            <div class="no-posts-icon text-danger">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h4>Error Loading ${type === 'missing' ? 'Missing' : 'Found'} Persons</h4>
            <p class="text-muted">We couldn't load the ${type} person reports. Please try again later.</p>
            <button class="btn btn-primary mt-2" onclick="loadCases('${type}')">
                <i class="fas fa-sync-alt me-2"></i>Try Again
            </button>
        </div>
    `);
    console.error('Error loading cases:', error);
}

function viewCaseDetails(caseId, caseType) {
    // Show loading state in modal
    $('#caseDetailsModal .modal-content').html(`
        <div class="modal-header">
            <h5 class="modal-title">Loading Details...</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    `);
    
    const modal = new bootstrap.Modal(document.getElementById('caseDetailsModal'));
    modal.show();
    
    $.ajax({
        url: `get_public_case_details.php`,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ 
            case_id: caseId,
            case_type: caseType
        }),
        success: function(response) {
            if (response.success) {
                showCaseModal(response.case, caseType);
            } else {
                $('#caseDetailsModal .modal-content').html(`
                    <div class="modal-header">
                        <h5 class="modal-title">Error</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger">
                            Failed to load case details: ${response.error || 'Unknown error'}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="viewCaseDetails('${caseId}', '${caseType}')">
                            <i class="fas fa-sync-alt me-2"></i>Try Again
                        </button>
                    </div>
                `);
            }
        },
        error: function(xhr, status, error) {
            $('#caseDetailsModal .modal-content').html(`
                <div class="modal-header">
                    <h5 class="modal-title">Error</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger">
                        Error loading case details: ${error}
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            `);
        }
    });
}

function showCaseModal(caseData, caseType) {
    const fullName = `${caseData.person_first_name || 'Unknown'} ${caseData.person_last_name || ''}`.trim();
    const imagePath = caseData.picture ? `uploads/${caseData.picture}` : 'uploads/default-profile.jpg';
    
    const modalHtml = `
        <div class="modal-header">
            <h5 class="modal-title">${caseType === 'missing' ? 'Missing Person' : 'Found Person'} Details</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-5 mb-4 mb-md-0">
                    <img src="${imagePath}" 
                         class="img-fluid rounded shadow-sm"
                         alt="${fullName}"
                         onerror="this.src='uploads/default-profile.jpg'">
                </div>
                <div class="col-md-7">
                    <h3 class="mb-3">${fullName}</h3>
                    
                    <div class="d-flex flex-wrap gap-3 mb-4">
                        <span class="badge ${caseType === 'missing' ? 'bg-danger' : 'bg-success'} p-2">
                            <i class="fas fa-${caseType === 'missing' ? 'search' : 'check-circle'} me-1"></i>
                            ${caseType === 'missing' ? 'Missing' : 'Found'}
                        </span>
                        <span class="badge bg-primary p-2">
                            <i class="fas fa-user me-1"></i>
                            ${caseData.person_age || 'Unknown'} years
                        </span>
                        <span class="badge bg-secondary p-2">
                            <i class="fas fa-${caseData.person_gender === 'Male' ? 'mars' : 'venus'} me-1"></i>
                            ${caseData.person_gender || 'Unknown'}
                        </span>
                    </div>
                    
                    <div class="mb-4">
                        <h5><i class="fas fa-map-marker-alt text-primary me-2"></i> ${caseType === 'missing' ? 'Last Seen' : 'Found'} Location</h5>
                        <p class="ps-4">${caseData.location || 'Unknown location'}</p>
                    </div>
                    
                    <div class="mb-4">
                        <h5><i class="fas fa-calendar-day text-primary me-2"></i> ${caseType === 'missing' ? 'Last Seen' : 'Found'} Date</h5>
                        <p class="ps-4">${formatDate(caseData.event_day)} at ${formatTime(caseData.event_time)}</p>
                    </div>
                    
                    <div class="mb-4">
                        <h5><i class="fas fa-align-left text-primary me-2"></i> Physical Description</h5>
                        <p class="ps-4">${caseData.physical_appearance || 'No description available'}</p>
                    </div>
                    
                    ${caseData.additional_description ? `
                    <div class="mb-4">
                        <h5><i class="fas fa-info-circle text-primary me-2"></i> Additional Information</h5>
                        <p class="ps-4">${caseData.additional_description}</p>
                    </div>
                    ` : ''}
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print me-2"></i>Print
            </button>
        </div>
    `;
    
    $('#caseDetailsModal .modal-content').html(modalHtml);
}

function formatDate(dateString) {
    if (!dateString) return 'Unknown date';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

function formatTime(timeString) {
    if (!timeString) return 'Unknown time';
    const [hours, minutes] = timeString.split(':');
    const timeDate = new Date();
    timeDate.setHours(hours, minutes);
    return timeDate.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}


